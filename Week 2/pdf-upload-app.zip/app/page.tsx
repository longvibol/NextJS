"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Upload, Download, FileText, X } from "lucide-react"

interface UploadedFile {
  id: string
  name: string
  size: number
  url: string
  uploadedAt: Date
}

export default function PDFUploadPage() {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (selectedFiles: FileList | null) => {
    if (!selectedFiles) return

    const pdfFiles = Array.from(selectedFiles).filter((file) => file.type === "application/pdf")

    const newFiles: UploadedFile[] = pdfFiles.map((file) => ({
      id: Math.random().toString(36).substring(7),
      name: file.name,
      size: file.size,
      url: URL.createObjectURL(file),
      uploadedAt: new Date(),
    }))

    setFiles((prev) => [...prev, ...newFiles])
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    handleFileSelect(e.dataTransfer.files)
  }

  const handleDownload = (file: UploadedFile) => {
    const link = document.createElement("a")
    link.href = file.url
    link.download = file.name
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handleRemove = (id: string) => {
    setFiles((prev) => prev.filter((file) => file.id !== id))
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i]
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="mb-16 border-4 border-primary bg-card p-8 sm:p-12">
          <h1 className="mb-4 font-sans text-4xl font-bold uppercase tracking-tight text-primary sm:text-5xl">
            PDF File Manager
          </h1>
          <p className="text-lg text-foreground">
            Upload, manage, and download your PDF files with ease. Simple, fast, and secure file handling in your
            browser.
          </p>
        </div>

        {/* Upload Section */}
        <div className="mb-12 border-4 border-primary bg-card p-8">
          <h2 className="mb-4 font-sans text-2xl font-bold uppercase text-primary">Step 1: Upload File</h2>
          <p className="mb-6 text-foreground">
            Upload your PDF files to view and manage them. Drag and drop or click to browse.
          </p>

          <div className="space-y-4">
            <div className="flex flex-col gap-4 sm:flex-row">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 border-4 border-primary bg-input px-6 py-4 text-center font-bold uppercase text-primary transition-colors hover:bg-secondary"
              >
                Upload file
              </button>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="bg-accent px-8 py-6 font-bold uppercase text-accent-foreground hover:bg-accent/90"
              >
                Browse
              </Button>
            </div>

            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-4 border-primary bg-input px-6 py-12 text-center transition-colors ${
                isDragging ? "bg-secondary" : ""
              }`}
            >
              <Upload className="mx-auto mb-3 h-8 w-8 text-primary" />
              <p className="font-bold uppercase text-primary">Drag & Drop a file here</p>
            </div>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf"
            multiple
            onChange={(e) => handleFileSelect(e.target.files)}
            className="hidden"
          />
        </div>

        {/* Files List Section */}
        {files.length > 0 && (
          <div className="border-4 border-primary bg-card p-8">
            <h2 className="mb-4 font-sans text-2xl font-bold uppercase text-primary">Step 2: Manage Files</h2>
            <p className="mb-6 text-foreground">
              Your uploaded files are listed below. Download or remove them as needed.
            </p>

            <div className="space-y-4">
              {files.map((file) => (
                <div key={file.id} className="flex items-center justify-between border-4 border-primary bg-input p-4">
                  <div className="flex items-center gap-4">
                    <FileText className="h-8 w-8 text-primary" />
                    <div>
                      <p className="font-bold text-primary">{file.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {formatFileSize(file.size)} • {file.uploadedAt.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleDownload(file)}
                      className="bg-accent font-bold uppercase text-accent-foreground hover:bg-accent/90"
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                    <Button
                      onClick={() => handleRemove(file.id)}
                      variant="outline"
                      size="icon"
                      className="border-2 border-primary text-primary hover:bg-destructive hover:text-destructive-foreground"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {files.length === 0 && (
          <div className="border-4 border-primary bg-card p-12 text-center">
            <FileText className="mx-auto mb-4 h-16 w-16 text-muted-foreground" />
            <h3 className="mb-2 font-sans text-xl font-bold uppercase text-primary">No Files Uploaded Yet</h3>
            <p className="text-muted-foreground">Upload your first PDF file to get started</p>
          </div>
        )}
      </div>
    </div>
  )
}
